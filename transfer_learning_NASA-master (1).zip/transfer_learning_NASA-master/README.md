# transfer_learning_NASA
Testing transfer learning among different milling condition

# HomePage

You can click [HERE](https://kidozh.com/projects/transfer_learning_NASA/) to see our project.

# Current Dev

+ replace `NaN` value by random forest algorithm
+ model creation
+ regression process established
+ trans-condition model prediction

# TODO

+ mechanism assumption for regression of deep learning

# Dependency

+ pandas
+ matplotlib
+ numpy
+ keras (with TensorFlow or other backend support)
+ scikit-learn (Random Forest Algorithm)

# LICENCE

MIT
